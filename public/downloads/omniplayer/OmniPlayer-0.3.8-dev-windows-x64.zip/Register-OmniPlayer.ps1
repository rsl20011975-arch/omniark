param([string]$Executable = (Join-Path $PSScriptRoot 'OmniPlayer.exe'))
$ErrorActionPreference = 'Stop'
$executablePath = [IO.Path]::GetFullPath($Executable)
if (-not (Test-Path -LiteralPath $executablePath -PathType Leaf)) { throw 'Omni Player executable is missing.' }

$extensions = @('.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.wmv', '.ts',
    '.mp3', '.flac', '.wav', '.ogg', '.opus', '.m4a', '.aac', '.wma')
$classesRoot = 'HKCU:\Software\Classes'
$applicationKey = Join-Path $classesRoot 'Applications\OmniPlayer.exe'
$programKey = Join-Path $classesRoot 'OmniPlayer.Media'
$command = '"' + $executablePath + '" "%1"'

function Get-OrCreateRegistryKey([string]$Path) {
    if (Test-Path -LiteralPath $Path) { return Get-Item -LiteralPath $Path }
    return New-Item -Path $Path
}

Get-OrCreateRegistryKey $applicationKey | Out-Null
New-ItemProperty -Path $applicationKey -Name 'FriendlyAppName' -PropertyType String -Value 'Omni Player' -Force | Out-Null
Get-OrCreateRegistryKey (Join-Path $applicationKey 'shell\open\command') | Out-Null
Set-Item -Path (Join-Path $applicationKey 'shell\open\command') -Value $command
$supportedTypes = Get-OrCreateRegistryKey (Join-Path $applicationKey 'SupportedTypes')
foreach ($extension in $extensions) {
    New-ItemProperty -Path $supportedTypes.PSPath -Name $extension -PropertyType String -Value '' -Force | Out-Null
}

Get-OrCreateRegistryKey $programKey | Out-Null
Set-Item -Path $programKey -Value 'Omni Player media'
Get-OrCreateRegistryKey (Join-Path $programKey 'DefaultIcon') | Out-Null
Set-Item -Path (Join-Path $programKey 'DefaultIcon') -Value ('"' + $executablePath + '",0')
Get-OrCreateRegistryKey (Join-Path $programKey 'shell\open\command') | Out-Null
Set-Item -Path (Join-Path $programKey 'shell\open\command') -Value $command

$capabilities = Get-OrCreateRegistryKey (Join-Path $applicationKey 'Capabilities')
New-ItemProperty -Path $capabilities.PSPath -Name 'ApplicationName' -PropertyType String -Value 'Omni Player' -Force | Out-Null
New-ItemProperty -Path $capabilities.PSPath -Name 'ApplicationDescription' -PropertyType String -Value 'Free local video and music player' -Force | Out-Null
$fileAssociations = Get-OrCreateRegistryKey (Join-Path $capabilities.PSPath 'FileAssociations')
foreach ($extension in $extensions) {
    New-ItemProperty -Path $fileAssociations.PSPath -Name $extension -PropertyType String -Value 'OmniPlayer.Media' -Force | Out-Null
    $openWith = Get-OrCreateRegistryKey (Join-Path $classesRoot ($extension + '\OpenWithProgids'))
    New-ItemProperty -Path $openWith.PSPath -Name 'OmniPlayer.Media' -PropertyType None -Value ([byte[]]@()) -Force | Out-Null
}

$registeredApplications = Get-OrCreateRegistryKey 'HKCU:\Software\RegisteredApplications'
New-ItemProperty -Path $registeredApplications.PSPath -Name 'Omni Player' -PropertyType String -Value 'Software\Classes\Applications\OmniPlayer.exe\Capabilities' -Force | Out-Null

$appPaths = Get-OrCreateRegistryKey 'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\OmniPlayer.exe'
Set-Item -Path $appPaths.PSPath -Value $executablePath
New-ItemProperty -Path $appPaths.PSPath -Name 'Path' -PropertyType String -Value ([IO.Path]::GetDirectoryName($executablePath)) -Force | Out-Null

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class OmniShellRefresh {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(uint eventId, uint flags, IntPtr item1, IntPtr item2);
}
'@ -ErrorAction SilentlyContinue
[OmniShellRefresh]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
Write-Host 'Omni Player is registered in Windows Open with.'
