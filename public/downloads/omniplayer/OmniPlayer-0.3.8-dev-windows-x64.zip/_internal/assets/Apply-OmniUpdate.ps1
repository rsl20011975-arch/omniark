param([Parameter(Mandatory=$true)][string]$Package, [Parameter(Mandatory=$true)][int]$ParentId)
$ErrorActionPreference = 'Stop'
$packageRoot = [IO.Path]::GetFullPath($Package)
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
if (-not $packageRoot.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected update staging path.' }
$session = Split-Path -Parent $packageRoot
if ((Split-Path -Leaf $session) -notlike 'omni-update-*' -or (Split-Path -Leaf $packageRoot) -ne 'package') { throw 'Unexpected update directory.' }
$log = Join-Path $session 'install.log'
try {
    if (Get-Process -Id $ParentId -ErrorAction SilentlyContinue) {
        try { Wait-Process -Id $ParentId -Timeout 45 }
        catch { if (Get-Process -Id $ParentId -ErrorAction SilentlyContinue) { throw } }
    }
    & (Join-Path $packageRoot 'Install-OmniPlayer.ps1') *>> $log
    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw 'Installer returned a failure.' }
    $installed = Join-Path $env:LOCALAPPDATA 'Programs\OmniPlayer\OmniPlayer.exe'
    if (-not (Test-Path -LiteralPath $installed)) { throw 'Installed executable missing.' }
    Start-Process -FilePath $installed -WorkingDirectory (Split-Path -Parent $installed)
} catch {
    $_ | Out-File -LiteralPath $log -Append -Encoding utf8
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show("Update failed. Previous installation and update log are preserved: $log", 'Omni Player update') | Out-Null
    exit 1
}
