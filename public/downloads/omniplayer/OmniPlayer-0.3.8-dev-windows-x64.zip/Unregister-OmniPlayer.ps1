param([string]$Executable = (Join-Path $PSScriptRoot 'OmniPlayer.exe'))
$ErrorActionPreference = 'Stop'
$executablePath = [IO.Path]::GetFullPath($Executable)
$extensions = @('.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.wmv', '.ts',
    '.mp3', '.flac', '.wav', '.ogg', '.opus', '.m4a', '.aac', '.wma')
$classesRoot = 'HKCU:\Software\Classes'
$applicationKey = Join-Path $classesRoot 'Applications\OmniPlayer.exe'
$expectedCommand = '"' + $executablePath + '" "%1"'
$commandKey = Get-Item -LiteralPath (Join-Path $applicationKey 'shell\open\command') -ErrorAction SilentlyContinue
$registeredCommand = if ($commandKey) { $commandKey.GetValue('') } else { $null }

# Do not remove registration that now belongs to another Omni Player installation.
if ($registeredCommand -and $registeredCommand -ne $expectedCommand) {
    Write-Warning 'A different Omni Player installation owns the file registration; it was preserved.'
    exit 0
}

Remove-Item -LiteralPath $applicationKey -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $classesRoot 'OmniPlayer.Media') -Recurse -Force -ErrorAction SilentlyContinue
$registeredApplications = 'HKCU:\Software\RegisteredApplications'
Remove-ItemProperty -LiteralPath $registeredApplications -Name 'Omni Player' -Force -ErrorAction SilentlyContinue
$appPaths = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\OmniPlayer.exe'
$appPathsKey = Get-Item -LiteralPath $appPaths -ErrorAction SilentlyContinue
if ($appPathsKey -and $appPathsKey.GetValue('') -eq $executablePath) {
    Remove-Item -LiteralPath $appPaths -Recurse -Force
}
foreach ($extension in $extensions) {
    $openWith = Join-Path $classesRoot ($extension + '\OpenWithProgids')
    Remove-ItemProperty -LiteralPath $openWith -Name 'OmniPlayer.Media' -Force -ErrorAction SilentlyContinue
}

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class OmniShellRefresh {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(uint eventId, uint flags, IntPtr item1, IntPtr item2);
}
'@ -ErrorAction SilentlyContinue
[OmniShellRefresh]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
Write-Host 'Omni Player Windows registration removed.'
