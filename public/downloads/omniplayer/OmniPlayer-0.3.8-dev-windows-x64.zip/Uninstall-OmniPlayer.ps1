param([switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$installRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$defaultRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\OmniPlayer'))
$testSuffix = [IO.Path]::Combine('test-output', 'install-test')
if ($installRoot -ne $defaultRoot -and -not $installRoot.EndsWith([IO.Path]::DirectorySeparatorChar + $testSuffix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsupported uninstall location.' }
if ((Get-Item -LiteralPath $installRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked locations are not supported.' }
$markerPath = Join-Path $installRoot '.omni-owned'
$manifestPath = Join-Path $installRoot 'manifest.json'
if (-not (Test-Path -LiteralPath $markerPath) -or -not (Test-Path -LiteralPath $manifestPath)) { throw 'Installation ownership record missing.' }
$markerText = [IO.File]::ReadAllText($markerPath).Trim()
$expectedManifestHash = $null
if ($markerText -ne 'OmniPlayer') {
    try { $marker = $markerText | ConvertFrom-Json }
    catch { throw 'Invalid installation ownership record.' }
    if ($marker.product -ne 'OmniPlayer' -or $marker.manifest_sha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid installation ownership record.' }
    $expectedManifestHash = $marker.manifest_sha256
}
if ($expectedManifestHash -and (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $expectedManifestHash) {
    throw 'Installation inventory changed; no files were removed.'
}
$running = Get-Process -Name OmniPlayer -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq (Join-Path $installRoot 'OmniPlayer.exe') }
if ($running) { throw 'Close Omni Player before uninstalling.' }
$unregister = Join-Path $installRoot 'Unregister-OmniPlayer.ps1'
if ($installRoot -eq $defaultRoot -and (Test-Path -LiteralPath $unregister)) {
    try { & $unregister }
    catch { Write-Warning 'Windows file registration could not be fully removed.' }
}
if ($installRoot -eq $defaultRoot) {
    Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmniPlayer' -Recurse -Force -ErrorAction SilentlyContinue
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.product -ne 'Omni Player' -or -not $manifest.files -or $manifest.files.Count -gt 10000) { throw 'Invalid installation inventory.' }
$pendingDirectories = [Collections.Generic.Stack[string]]::new()
$pendingDirectories.Push($installRoot)
while ($pendingDirectories.Count) {
    foreach ($item in Get-ChildItem -LiteralPath $pendingDirectories.Pop() -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked installation entries are not supported.' }
        if ($item.PSIsContainer) { $pendingDirectories.Push($item.FullName) }
    }
}
$declared = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in $manifest.files) {
    if ($entry.path -isnot [string] -or [string]::IsNullOrWhiteSpace($entry.path)) { throw 'Invalid installed path.' }
    $file = [IO.Path]::GetFullPath((Join-Path $installRoot $entry.path))
    if (-not $file.StartsWith($installRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or -not $declared.Add($file)) { throw 'Invalid or duplicate installed path.' }
}
foreach ($file in $declared) {
    if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file -Force }
}
foreach ($name in @('manifest.json', '.omni-owned')) {
    Remove-Item -LiteralPath (Join-Path $installRoot $name) -Force -ErrorAction SilentlyContinue
}
if (-not $NoShortcut) {
    $programs = [Environment]::GetFolderPath('Programs')
    Remove-Item -LiteralPath (Join-Path $programs 'Omni Player.lnk') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $programs 'Omni Player') -Recurse -Force -ErrorAction SilentlyContinue
}
Get-ChildItem -LiteralPath $installRoot -Directory -Recurse | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
    if (-not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -and -not (Get-ChildItem -LiteralPath $_.FullName -Force)) {
        Remove-Item -LiteralPath $_.FullName
    }
}
if (-not (Get-ChildItem -LiteralPath $installRoot -Force)) { Remove-Item -LiteralPath $installRoot }
Write-Host 'Omni Player program files removed. User settings and unrelated files are preserved.'
