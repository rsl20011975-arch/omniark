@echo off
powershell.exe -NoProfile -File "%~dp0Uninstall-OmniPlayer.ps1"
pause
