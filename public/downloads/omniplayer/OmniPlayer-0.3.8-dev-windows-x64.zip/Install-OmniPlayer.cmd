@echo off
powershell.exe -NoProfile -File "%~dp0Install-OmniPlayer.ps1"
pause
