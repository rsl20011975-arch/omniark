param([string]$Destination = (Join-Path $env:LOCALAPPDATA 'Programs\OmniPlayer'), [switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$sourceRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$installRoot = [IO.Path]::GetFullPath($Destination)
$defaultRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\OmniPlayer'))
$testRoot = [IO.Path]::GetFullPath((Join-Path $sourceRoot '..\..\test-output\install-test'))
if ($installRoot -ne $defaultRoot -and $installRoot -ne $testRoot) { throw 'Unsupported installation destination.' }
if ($installRoot -eq $sourceRoot) { throw 'Source and destination cannot be identical.' }
if (Test-Path -LiteralPath $installRoot) {
    if (-not (Test-Path -LiteralPath (Join-Path $installRoot '.omni-owned'))) { throw 'Destination is not an Omni installation.' }
    if ((Get-Item -LiteralPath $installRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked destinations are not supported.' }
}
$manifestPath = Join-Path $sourceRoot 'manifest.json'
$manifestText = Get-Content -LiteralPath $manifestPath -Raw
$manifest = $manifestText | ConvertFrom-Json
$manifestHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash
$declared = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if ($manifest.product -ne 'Omni Player' -or -not $manifest.files -or $manifest.files.Count -gt 10000) { throw 'Invalid package inventory.' }
foreach ($entry in $manifest.files) {
    $file = [IO.Path]::GetFullPath((Join-Path $sourceRoot $entry.path))
    if (-not $file.StartsWith($sourceRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid package path.' }
    if (-not $declared.Add($file) -or $entry.sha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Duplicate or invalid inventory entry.' }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Damaged package: $($entry.path)" }
}
foreach ($item in Get-ChildItem -LiteralPath $sourceRoot -Force -Recurse) {
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked package entries are not supported.' }
    if (-not $item.PSIsContainer -and $item.FullName -ne (Join-Path $sourceRoot 'manifest.json') -and -not $declared.Contains($item.FullName)) {
        throw "Undeclared package file: $($item.Name)"
    }
}
$personalFiles = @()
if (Test-Path -LiteralPath $installRoot) {
    $oldManifestPath = Join-Path $installRoot 'manifest.json'
    $oldMarkerPath = Join-Path $installRoot '.omni-owned'
    if (-not (Test-Path -LiteralPath $oldManifestPath)) { throw 'Existing installation inventory missing.' }
    foreach ($item in Get-ChildItem -LiteralPath $installRoot -Force -Recurse) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked installation entries are not supported.' }
    }
    $oldMarkerText = [IO.File]::ReadAllText($oldMarkerPath).Trim()
    if ($oldMarkerText -ne 'OmniPlayer') {
        try { $oldMarker = $oldMarkerText | ConvertFrom-Json }
        catch { throw 'Invalid existing installation ownership record.' }
        if ($oldMarker.product -ne 'OmniPlayer' -or $oldMarker.manifest_sha256 -notmatch '^[0-9a-fA-F]{64}$' -or
            (Get-FileHash -LiteralPath $oldManifestPath -Algorithm SHA256).Hash -ne $oldMarker.manifest_sha256) {
            throw 'Existing installation inventory changed; update was stopped.'
        }
    }
    $oldManifest = Get-Content -LiteralPath $oldManifestPath -Raw | ConvertFrom-Json
    if ($oldManifest.product -ne 'Omni Player' -or -not $oldManifest.files -or $oldManifest.files.Count -gt 10000) { throw 'Invalid existing installation inventory.' }
    $oldDeclared = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $oldManifest.files) {
        if ($entry.path -isnot [string] -or [string]::IsNullOrWhiteSpace($entry.path)) { throw 'Invalid existing installation path.' }
        $oldFile = [IO.Path]::GetFullPath((Join-Path $installRoot $entry.path))
        if (-not $oldFile.StartsWith($installRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or -not $oldDeclared.Add($oldFile)) {
            throw 'Invalid or duplicate existing installation path.'
        }
    }
    $personalFiles = @(Get-ChildItem -LiteralPath $installRoot -Force -Recurse -File | Where-Object {
        $_.FullName -ne $oldManifestPath -and $_.FullName -ne $oldMarkerPath -and -not $oldDeclared.Contains($_.FullName)
    } | ForEach-Object { [IO.Path]::GetRelativePath($installRoot, $_.FullName) })
}
$running = Get-Process -Name OmniPlayer -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq (Join-Path $installRoot 'OmniPlayer.exe') }
if ($running) { throw 'Close Omni Player before installing an update.' }
$staging = $installRoot + '.staging-' + [Guid]::NewGuid().ToString('N')
$backup = $installRoot + '.previous-' + [Guid]::NewGuid().ToString('N')
New-Item -ItemType Directory -Path $staging -Force | Out-Null
try {
    foreach ($entry in $manifest.files) {
        $stagedFile = Join-Path $staging $entry.path
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($stagedFile)) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $sourceRoot $entry.path) -Destination $stagedFile
    }
    [IO.File]::WriteAllText((Join-Path $staging 'manifest.json'), $manifestText, [Text.UTF8Encoding]::new($false))
    foreach ($entry in $manifest.files) {
        if ((Get-FileHash -LiteralPath (Join-Path $staging $entry.path) -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'Package changed while copying.' }
    }
    $ownership = [ordered]@{ product = 'OmniPlayer'; manifest_sha256 = $manifestHash } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText((Join-Path $staging '.omni-owned'), $ownership, [Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $installRoot) { Move-Item -LiteralPath $installRoot -Destination $backup }
    try { Move-Item -LiteralPath $staging -Destination $installRoot }
    catch {
        if (Test-Path -LiteralPath $backup) { Move-Item -LiteralPath $backup -Destination $installRoot }
        throw
    }
    foreach ($relative in $personalFiles) {
        $savedFile = Join-Path $backup $relative
        $restoredFile = Join-Path $installRoot $relative
        if (Test-Path -LiteralPath $restoredFile) {
            Write-Warning "A personal file conflicts with the new package and remains in the previous-version folder: $relative"
            continue
        }
        try {
            New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($restoredFile)) -Force | Out-Null
            Copy-Item -LiteralPath $savedFile -Destination $restoredFile
        } catch {
            Write-Warning "A personal file could not be restored in place and remains in the previous-version folder: $relative"
        }
    }
    if (-not $NoShortcut) {
        try {
            $shell = New-Object -ComObject WScript.Shell
            $programFolder = Join-Path ([Environment]::GetFolderPath('Programs')) 'Omni Player'
            New-Item -ItemType Directory -Path $programFolder -Force | Out-Null
            $shortcutPath = Join-Path $programFolder 'Omni Player.lnk'
            $shortcut = $shell.CreateShortcut($shortcutPath)
            $shortcut.TargetPath = Join-Path $installRoot 'OmniPlayer.exe'
            $shortcut.WorkingDirectory = $installRoot
            $shortcut.IconLocation = (Join-Path $installRoot 'OmniPlayer.exe') + ',0'
            $shortcut.Save()
            $uninstallShortcut = $shell.CreateShortcut((Join-Path $programFolder 'Omni Player 제거.lnk'))
            $uninstallShortcut.TargetPath = Join-Path $installRoot 'OmniPlayer 제거.exe'
            $uninstallShortcut.WorkingDirectory = $installRoot
            $uninstallShortcut.IconLocation = (Join-Path $installRoot 'OmniPlayer 제거.exe') + ',0'
            $uninstallShortcut.Save()
            Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) 'Omni Player.lnk') -Force -ErrorAction SilentlyContinue
        } catch {
            Write-Warning 'Program installation succeeded, but the Start menu shortcut could not be created.'
        }
    }
    if ($installRoot -eq $defaultRoot) {
        try { & (Join-Path $installRoot 'Register-OmniPlayer.ps1') }
        catch { Write-Warning 'Program installation succeeded, but Windows file registration could not be completed.' }
        try {
            $uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmniPlayer'
            New-Item -Path $uninstallKey -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name DisplayName -PropertyType String -Value 'Omni Player' -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name DisplayVersion -PropertyType String -Value ([string]$manifest.version) -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name Publisher -PropertyType String -Value 'OMNIARK' -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name InstallLocation -PropertyType String -Value $installRoot -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name DisplayIcon -PropertyType String -Value ((Join-Path $installRoot 'OmniPlayer.exe') + ',0') -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name UninstallString -PropertyType String -Value ('"' + (Join-Path $installRoot 'OmniPlayer 제거.exe') + '"') -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name NoModify -PropertyType DWord -Value 1 -Force | Out-Null
            New-ItemProperty -Path $uninstallKey -Name NoRepair -PropertyType DWord -Value 1 -Force | Out-Null
            $estimatedSize = [Math]::Ceiling((($manifest.files | Measure-Object -Property bytes -Sum).Sum + (Get-Item -LiteralPath $manifestPath).Length) / 1KB)
            New-ItemProperty -Path $uninstallKey -Name EstimatedSize -PropertyType DWord -Value ([int]$estimatedSize) -Force | Out-Null
        } catch {
            Write-Warning 'Program installation succeeded, but the Windows installed-app entry could not be created.'
        }
    }
    Write-Host "Installed: $installRoot"
    if (Test-Path -LiteralPath $backup) { Write-Host "Previous version preserved: $backup" }
} catch {
    Write-Error $_
    exit 1
} finally {
    # A failed copy or swap must not leave a full package in the staging path.
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
}
