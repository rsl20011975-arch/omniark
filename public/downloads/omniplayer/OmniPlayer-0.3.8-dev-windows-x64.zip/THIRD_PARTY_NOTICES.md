# Third-party inventory — Omni Player 0.3 development build

Dynamically loaded libraries are used. This is a local development package;
public-release compliance is not yet certified.

- Python 3.12.14: https://github.com/python/cpython/tree/v3.12.14
- PySide6 / Shiboken 6.11.2: https://download.qt.io/official_releases/QtForPython/pyside6/PySide6-6.11.2-src/
- Qt 6.11.2: https://download.qt.io/official_releases/qt/6.11/6.11.2/submodules/
- FFmpeg DLLs 7.1.5: https://github.com/FFmpeg/FFmpeg/tree/n7.1.5
- TinyTag 2.3.2 (MIT): https://github.com/tinytag/tinytag
- PyInstaller 6.12.0 (bootloader exception): https://github.com/pyinstaller/pyinstaller/tree/v6.12.0

licenses/ includes LGPL 2.1, LGPL 3, GPL 3, Python, FFmpeg, TinyTag and
PyInstaller texts. This is not a complete per-file Qt dependency audit.
Microsoft runtime DLL redistribution terms must also be included for public release.

The included FFmpeg DLL reports LGPL version 2.1 or later. Build configuration:

--prefix=/c/FFmpeg-n7.1.5/build/msvc/installed --disable-programs --disable-doc
--disable-debug --enable-network --disable-lzma --enable-pic --disable-vulkan
--disable-v4l2-m2m --disable-decoder=truemotion1 --disable-avdevice
--disable-avfilter --enable-zlib --extra-cflags=-IC:/zlib-1.3.1/build/amd64
--extra-ldflags=-LIBPATH:C:/zlib-1.3.1/build/amd64 --toolchain=msvc
--enable-shared --disable-static

This configuration describes the DLL, not Omni UI network capabilities.
Before public release: audit the complete manifest, include every applicable
notice and corresponding sources/build materials, verify library replacement
rights and codec redistribution conditions. SHA-256 checks prove integrity,
not publisher identity. No release signature is present.

VLC in test-output/baselines is a separate verified test tool and is not shipped.

libass 0.17.5 (ISC): https://github.com/libass/libass/tree/0.17.5
Native dependency provenance and exact hashes: _internal/native/libass/runtime.json.
Only the 20 DLLs listed there are shipped. MSYS2 package-origin hashes were verified.
The contributing runtime-package notices are included under licenses/libass-runtime;
additional notices from fetched build dependencies may also be present.
libass uses the DirectWrite font provider on Windows. This does not remove the need
for the overall public-release license and corresponding-source audit noted above.
