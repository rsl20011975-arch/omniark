$ErrorActionPreference = 'Stop'
function Assert-NoLinks([string]$Path) {
    $part=[IO.Path]::GetFullPath($Path)
    while ($part) { if (Test-Path -LiteralPath $part) { if ((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $part" } }; $part=[IO.Path]::GetDirectoryName($part) }
}
$actual=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
Assert-NoLinks $actual
$manifestPath=Join-Path $actual 'install-manifest.json'
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.AppId -ne 'OmniZip' -or $manifest.Instance -notmatch '^OmniZip(?:\.Test-[a-f0-9]{32})?$') { throw 'Invalid installation manifest.' }
$expected=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA ('Programs\' + $manifest.Instance))).TrimEnd('\')
if ($actual -ne $expected -or $manifest.Root -ne $expected) { throw 'Uninstaller must run from its original installation directory.' }
$known=@('OmniZip.exe','README.md','THIRD-PARTY.md','Uninstall-OmniZip.ps1','engine\7z.exe','engine\7z.dll','engine\License.txt','engine\7z2603-src.tar.xz')
# Preflight every owned path before changing anything.
foreach ($name in $known) { Assert-NoLinks (Join-Path $actual $name) }
$shortcut=Join-Path ([Environment]::GetFolderPath('Programs')) ($manifest.Instance + '.lnk')
Assert-NoLinks $shortcut
if (Test-Path -LiteralPath $shortcut) { $shell=New-Object -ComObject WScript.Shell; $link=$shell.CreateShortcut($shortcut); if ($link.TargetPath -eq (Join-Path $actual 'OmniZip.exe')) { Remove-Item -LiteralPath $shortcut } else { Write-Output 'Preserved a shortcut changed by another application.' } }
$menuPath='Software\Classes\*\shell\' + $manifest.Instance + '.Open'
$key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($menuPath)
if ($key) { $owner=$key.GetValue('OmniZipOwner'); $key.Dispose(); if ($owner -eq $actual) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($menuPath,$false) } else { Write-Output 'Preserved an Explorer menu owned by another application.' } }
$preserved=0
foreach ($name in $known) {
    $file=Join-Path $actual $name
    if (Test-Path -LiteralPath $file) {
        $expectedHash=$manifest.Files.PSObject.Properties[$name].Value
        if ($expectedHash -and (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -eq $expectedHash) { Remove-Item -LiteralPath $file } else { $preserved++; Write-Output "Preserved modified file: $name" }
    }
}
$engine=Join-Path $actual 'engine'
if ((Test-Path -LiteralPath $engine) -and @(Get-ChildItem -LiteralPath $engine -Force).Count -eq 0) { Remove-Item -LiteralPath $engine }
Remove-Item -LiteralPath $manifestPath
if (@(Get-ChildItem -LiteralPath $actual -Force).Count -eq 0) { Remove-Item -LiteralPath $actual }
Write-Output "Uninstalled. Modified files preserved: $preserved. User-created files and extraction backups were not removed."
