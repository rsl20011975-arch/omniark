param([switch]$ExplorerMenu,[ValidatePattern('^OmniZip(?:\.Test-[a-f0-9]{32})?$')][string]$InstanceName = 'OmniZip')
$ErrorActionPreference = 'Stop'
function Assert-NoLinks([string]$Path) {
    $part=[IO.Path]::GetFullPath($Path)
    while ($part) { if (Test-Path -LiteralPath $part) { if ((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $part" } }; $part=[IO.Path]::GetDirectoryName($part) }
}
$parent=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs'))
$target=Join-Path $parent $InstanceName
Assert-NoLinks $target
if (Test-Path -LiteralPath $target) { throw 'Installation directory already exists. Uninstall the existing copy first.' }
$files=@('OmniZip.exe','README.md','THIRD-PARTY.md','Uninstall-OmniZip.ps1','engine\7z.exe','engine\7z.dll','engine\License.txt','engine\7z2603-src.tar.xz')
foreach ($name in $files) { $source=Join-Path $PSScriptRoot $name; if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Package file missing: $name" }; Assert-NoLinks $source }
$linkPath=Join-Path ([Environment]::GetFolderPath('Programs')) ($InstanceName + '.lnk')
Assert-NoLinks $linkPath
if (Test-Path -LiteralPath $linkPath) { throw 'A shortcut with this name already exists.' }
$menuPath='Software\Classes\*\shell\' + $InstanceName + '.Open'
$existing=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($menuPath)
if ($existing) { $existing.Dispose(); if ($ExplorerMenu) { throw 'An Explorer menu with this name already exists.' } }
$stage=Join-Path $parent ('.' + $InstanceName + '-setup-' + [Guid]::NewGuid().ToString('N'))
$published=$false; $madeLink=$false; $madeMenu=$false
try {
    New-Item -ItemType Directory -Path (Join-Path $stage 'engine') -Force | Out-Null
    $hashes=@{}
    foreach ($name in $files) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $stage $name); $hashes[$name]=(Get-FileHash -LiteralPath (Join-Path $stage $name) -Algorithm SHA256).Hash }
    @{ AppId='OmniZip'; Instance=$InstanceName; Root=$target; Files=$hashes; ExplorerMenu=[bool]$ExplorerMenu } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $stage 'install-manifest.json') -Encoding UTF8
    Move-Item -LiteralPath $stage -Destination $target
    $published=$true
    $shell=New-Object -ComObject WScript.Shell
    $link=$shell.CreateShortcut($linkPath); $link.TargetPath=Join-Path $target 'OmniZip.exe'; $link.WorkingDirectory=$target; $link.Save(); $madeLink=$true
    if ($ExplorerMenu) {
        $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($menuPath)
        try { $madeMenu=$true; $key.SetValue('','Open with OmniZip'); $key.SetValue('Icon',(Join-Path $target 'OmniZip.exe')); $key.SetValue('OmniZipOwner',$target); $command=$key.CreateSubKey('command'); try { $command.SetValue('',('"' + (Join-Path $target 'OmniZip.exe') + '" "%1"')) } finally { $command.Dispose() } } finally { $key.Dispose() }
    }
    Write-Output "Installed: $target"
    Write-Output 'Default file associations were not changed.'
} catch {
    if ($madeMenu) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($menuPath,$false) }
    if ($madeLink -and (Test-Path -LiteralPath $linkPath)) { Remove-Item -LiteralPath $linkPath }
    $cleanup=if ($published) { $target } else { $stage }
    $resolved=[IO.Path]::GetFullPath($cleanup)
    if (-not $resolved.StartsWith($parent.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Rollback path was outside the installation parent.' }
    if (Test-Path -LiteralPath $resolved) { Assert-NoLinks $resolved; foreach ($entry in Get-ChildItem -LiteralPath $resolved -Recurse -Force) { Assert-NoLinks $entry.FullName }; Remove-Item -LiteralPath $resolved -Recurse }
    throw
}
