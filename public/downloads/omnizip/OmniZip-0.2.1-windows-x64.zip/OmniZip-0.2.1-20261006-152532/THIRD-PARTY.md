# Third-party components

## 7-Zip 26.03, Windows x64

Copyright (C) 1999-2026 Igor Pavlov. The app launches the unmodified 7z.exe and 7z.dll as a separate process. RAR is supported for reading only.

Official download page: https://www.7-zip.org/download.html

Source and binary release: https://github.com/ip7z/7zip/releases/tag/26.03

The portable package includes `engine/License.txt` and the corresponding complete source archive `engine/7z2603-src.tar.xz`. The license includes LGPL terms, BSD notices and the unRAR restriction. These files must remain with redistributed copies. The engine binaries can be replaced independently; no signature enforcement or modifications are applied by OmniZip.

Downloaded binaries (SHA-256):

- 7z.exe: 6EE3C0ED0B27663C1B948AE85A7C0BB073AED1498983182F3F0DF1F6A8C30B2F
- 7z.dll: 65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D
- 7z2603-src.tar.xz: 9CBDE5099C6DEB73691B0579063DA5827522CCBBCBA3F0020FD04E8C8C16C0D4

## libarchive RAR test fixtures

Development-only fixtures, not part of the portable app:

- `basic.rar.uu`: https://github.com/libarchive/libarchive/blob/master/libarchive/test/test_read_format_rar.rar.uu
- `windows.rar.uu`: https://github.com/libarchive/libarchive/blob/master/libarchive/test/test_read_format_rar_windows.rar.uu

See `tests/fixtures/LIBARCHIVE-LICENSE.txt`. Downloaded 2026-10-06. These fixtures verify ordinary RAR extraction and rejection of symbolic links.
