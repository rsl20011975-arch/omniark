param([switch]$ExplorerMenu,[ValidatePattern('^OmniZip(?:\.Test-[a-f0-9]{32})?$')][string]$InstanceName = 'OmniZip')
$ErrorActionPreference = 'Stop'
function Assert-NoLinks([string]$Path) {
    $part=[IO.Path]::GetFullPath($Path)
    while ($part) { if (Test-Path -LiteralPath $part) { if ((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $part" } }; $part=[IO.Path]::GetDirectoryName($part) }
}
$parent=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs'))
$target=Join-Path $parent $InstanceName
Assert-NoLinks $target
if (Test-Path -LiteralPath $target) { throw 'Installation directory already exists. Uninstall the existing copy first.' }
$files=@('OmniZip.exe','OmniZip.png','README.md','THIRD-PARTY.md','Uninstall-OmniZip.ps1','engine\7z.exe','engine\7z.dll','engine\License.txt','engine\7z2603-src.tar.xz')
foreach ($name in $files) { $source=Join-Path $PSScriptRoot $name; if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Package file missing: $name" }; Assert-NoLinks $source }
$linkPath=Join-Path ([Environment]::GetFolderPath('Programs')) ($InstanceName + '.lnk')
Assert-NoLinks $linkPath
if (Test-Path -LiteralPath $linkPath) { throw 'A shortcut with this name already exists.' }
$menuPath='Software\Classes\*\shell\' + $InstanceName + '.Open'
$extensions=@('.zip','.7z','.rar','.001')
$progId=$InstanceName + '.Archive'
$progIdPath='Software\Classes\' + $progId
$capabilitiesPath='Software\Classes\' + $InstanceName + '.Capabilities'
$registeredPath='Software\RegisteredApplications'
$applicationPath='Software\Classes\Applications\' + $InstanceName + '.exe'
$existing=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($menuPath)
if ($existing) { $existing.Dispose(); if ($ExplorerMenu) { throw 'An Explorer menu with this name already exists.' } }
foreach ($registrationPath in @($progIdPath,$capabilitiesPath,$applicationPath)) { $existing=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registrationPath); if ($existing) { $existing.Dispose(); throw "An application registration already exists: $registrationPath" } }
$registered=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registeredPath)
if ($registered) { try { if ($null -ne $registered.GetValue($InstanceName,$null)) { throw 'A RegisteredApplications entry with this name already exists.' } } finally { $registered.Dispose() } }
$stage=Join-Path $parent ('.' + $InstanceName + '-setup-' + [Guid]::NewGuid().ToString('N'))
$published=$false; $madeLink=$false; $madeMenu=$false; $madeAssociations=$false
try {
    New-Item -ItemType Directory -Path (Join-Path $stage 'engine') -Force | Out-Null
    $hashes=@{}
    foreach ($name in $files) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $stage $name); $hashes[$name]=(Get-FileHash -LiteralPath (Join-Path $stage $name) -Algorithm SHA256).Hash }
    @{ AppId='OmniZip'; Instance=$InstanceName; Root=$target; Files=$hashes; ExplorerMenu=[bool]$ExplorerMenu; Associations=$true; ProgId=$progId; Capabilities=$capabilitiesPath; ApplicationKey=$applicationPath } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $stage 'install-manifest.json') -Encoding UTF8
    Move-Item -LiteralPath $stage -Destination $target
    $published=$true
    $shell=New-Object -ComObject WScript.Shell
    $link=$shell.CreateShortcut($linkPath); $link.TargetPath=Join-Path $target 'OmniZip.exe'; $link.WorkingDirectory=$target; $link.Save(); $madeLink=$true
    if ($ExplorerMenu) {
        $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($menuPath)
        try { $madeMenu=$true; $key.SetValue('','Open with OmniZip'); $key.SetValue('Icon',(Join-Path $target 'OmniZip.exe')); $key.SetValue('OmniZipOwner',$target); $command=$key.CreateSubKey('command'); try { $command.SetValue('',('"' + (Join-Path $target 'OmniZip.exe') + '" "%1"')) } finally { $command.Dispose() } } finally { $key.Dispose() }
    }
    $exe=Join-Path $target 'OmniZip.exe'
    $madeAssociations=$true
    $prog=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($progIdPath)
    try { $prog.SetValue('','OmniZip archive'); $prog.SetValue('OmniZipOwner',$target) } finally { $prog.Dispose() }
    $icon=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($progIdPath + '\DefaultIcon')
    try { $icon.SetValue('',('"' + $exe + '",0')) } finally { $icon.Dispose() }
    $open=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($progIdPath + '\shell\open\command')
    try { $open.SetValue('',('"' + $exe + '" "%1"')) } finally { $open.Dispose() }
    $cap=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($capabilitiesPath)
    try { $cap.SetValue('ApplicationName','OmniZip'); $cap.SetValue('ApplicationDescription','Open and extract ZIP, 7Z, and RAR archives.'); $cap.SetValue('OmniZipOwner',$target) } finally { $cap.Dispose() }
    $fileCaps=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($capabilitiesPath + '\FileAssociations')
    try { foreach ($extension in $extensions) { $fileCaps.SetValue($extension,$progId) } } finally { $fileCaps.Dispose() }
    $registered=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($registeredPath)
    try { $registered.SetValue($InstanceName,$capabilitiesPath) } finally { $registered.Dispose() }
    $app=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($applicationPath)
    try { $app.SetValue('FriendlyAppName','OmniZip'); $app.SetValue('OmniZipOwner',$target) } finally { $app.Dispose() }
    $appOpen=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($applicationPath + '\shell\open\command')
    try { $appOpen.SetValue('',('"' + $exe + '" "%1"')) } finally { $appOpen.Dispose() }
    $supported=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($applicationPath + '\SupportedTypes')
    try { foreach ($extension in $extensions) { $supported.SetValue($extension,'') } } finally { $supported.Dispose() }
    foreach ($extension in $extensions) {
        $with=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Classes\' + $extension + '\OpenWithProgids')
        try { $with.SetValue($progId,[byte[]]@(),[Microsoft.Win32.RegistryValueKind]::None) } finally { $with.Dispose() }
    }
    Write-Output "Installed: $target"
    Write-Output 'Registered OmniZip in Open with for ZIP, 7Z, RAR, and split archive files. Existing defaults were not changed.'
} catch {
    if ($madeAssociations) {
        foreach ($extension in $extensions) { $with=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Classes\' + $extension + '\OpenWithProgids',$true); if ($with) { try { $with.DeleteValue($progId,$false) } finally { $with.Dispose() } } }
        $registered=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registeredPath,$true); if ($registered) { try { $registered.DeleteValue($InstanceName,$false) } finally { $registered.Dispose() } }
        [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($applicationPath,$false)
        [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($capabilitiesPath,$false)
        [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($progIdPath,$false)
    }
    if ($madeMenu) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($menuPath,$false) }
    if ($madeLink -and (Test-Path -LiteralPath $linkPath)) { Remove-Item -LiteralPath $linkPath }
    $cleanup=if ($published) { $target } else { $stage }
    $resolved=[IO.Path]::GetFullPath($cleanup)
    if (-not $resolved.StartsWith($parent.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Rollback path was outside the installation parent.' }
    if (Test-Path -LiteralPath $resolved) { Assert-NoLinks $resolved; foreach ($entry in Get-ChildItem -LiteralPath $resolved -Recurse -Force) { Assert-NoLinks $entry.FullName }; Remove-Item -LiteralPath $resolved -Recurse }
    throw
}
